//! Source-only screenshot region detection, ported from `python/pipeline.py`.
//!
//! The public facade is backend-independent. Images enter through [`BgrImage`]
//! and [`detect_regions`]; exporting results is a separate operation. Pure Rust
//! processing is the default. Enable the `opencv` feature to select the
//! OpenCV primitive backend and use [`opencv_backend`] for `Mat` interop.
pub use error::{Error, Result};
pub use geometry::{Rect, iou};
pub use grid::BgrImage;
pub use model::Region;
#[cfg(feature = "file-io")]
pub use output::write_crops;
pub use output::{draw_regions, regions_to_jsonable};
pub use pipeline::detect_regions;

#[cfg(feature = "opencv")]
pub mod opencv_backend;

/// Name of the compile-time-selected processing backend.
pub fn backend_name() -> &'static str {
    backend::name()
}

mod backend;
mod color;
mod error;
mod geometry;
mod grid;
mod icons;
mod mask;
mod media;
mod model;
mod output;
mod pipeline;
mod selection;
mod surfaces;
mod text;

use std::cell::RefCell;

pub(crate) struct SerialScope;
impl SerialScope {
    pub(crate) fn spawn(&self, f: impl FnOnce()) { f(); }
}
pub(crate) fn serial_scope<T>(f: impl FnOnce(&SerialScope) -> T) -> T { f(&SerialScope) }

thread_local! {
    static PIXELS: RefCell<Vec<u8>> = const { RefCell::new(Vec::new()) };
    static RECTS: RefCell<Vec<i32>> = const { RefCell::new(Vec::new()) };
}

#[unsafe(no_mangle)]
pub extern "C" fn region_input(size: usize) -> *mut u8 {
    PIXELS.with_borrow_mut(|p| { p.resize(size, 0); p.as_mut_ptr() })
}

#[unsafe(no_mangle)]
pub extern "C" fn region_detect(width: u32, height: u32) -> usize {
    let result = PIXELS.with_borrow(|p| {
        let bgr = p.chunks_exact(4).flat_map(|rgba| [rgba[2], rgba[1], rgba[0]]).collect();
        BgrImage::from_bgr_bytes(width,height,bgr)
            .and_then(|image| detect_regions(&image))
    });
    RECTS.with_borrow_mut(|rects| {
        rects.clear();
        if let Ok(regions) = result {
            for region in regions {
                let r = region.rect;
                rects.extend([r.x,r.y,r.w,r.h]);
            }
        }
        rects.len() / 4
    })
}

#[unsafe(no_mangle)]
pub extern "C" fn region_output() -> *const i32 {
    RECTS.with_borrow(|rects| rects.as_ptr())
}